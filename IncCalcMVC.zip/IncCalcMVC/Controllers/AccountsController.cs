﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using IncCalcMVC.Models;
using System.Data.SqlClient;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace IncCalcMVC.Controllers
{
    public class AccountsController : Controller
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cod = new SqlCommand();
        SqlDataReader dr;
        // GET: /<controller>/
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        void connectionString()
        {

            con.ConnectionString = "dataSource";
        }

        [HttpPost]

        public IActionResult Verify(Accounts acc)
        {
            connectionString();
            con.Open();
            cod.Connection = con;
            cod.CommandText = "select * from tbl_login where username='"+acc.Name+"' and password='"+acc.Password+"'";
            dr = cod.ExecuteReader();
            if (dr.Read())
            {
                con.Close();
                return View(Create);
            }
            else
            {
                con.Close();
                return View(Error);
            }



        }
    }
}
