﻿using System;
namespace IncCalcMVC.Models
{
    public class Accounts
    {
        public string Name { get; set; }
        public string Password { get; set; }

        public Accounts()
        {


        }
    }
}


